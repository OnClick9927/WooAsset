﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuGuideConst 
{
    public const string ClickBtnStart = "ClickBtnStart";
    public const string ClickBtn55 = "ClickBtn5";
}
