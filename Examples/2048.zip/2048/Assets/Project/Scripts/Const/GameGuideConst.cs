﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameGuideConst  
{
    public const string  MoveUp = "MoveUp";
    public const string MoveDown = "MoveDown";
    public const string MoveLeft = "MoveLeft";
    public const string MoveRight = "MoveRight";
    public const string ClickLast = "ClickLast";
    public const string ClickRestart = "ClickRestart";
    public const string ClickBack = "ClickBack";
}
