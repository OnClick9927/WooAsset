﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum MoveType 
{
    TOP,
    DOWN,
    LEFT,
    RIGHT ,None
}
