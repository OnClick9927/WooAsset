﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum NumberStatus
{
     Normal,   // 正常状态
     NotMerge, // 不能合并的状态
}
